# Plugin de Login Externo

Este plugin proporciona una funcionalidad de inicio de sesión y registro en WordPress utilizando una base de datos externa.

## Instalación
1. Coloca el plugin en el directorio `wp-content/plugins/plugin_login`.
2. Activa el plugin desde el panel de administración de WordPress.

## Uso
Utiliza el shortcode `[formulario_inicio_sesion_registro]` para mostrar el formulario de inicio de sesión y registro.
